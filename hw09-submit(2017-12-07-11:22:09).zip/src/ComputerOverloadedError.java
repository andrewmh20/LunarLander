
public class ComputerOverloadedError extends Error {

    @Override
    public void causeFailure(LunarModel lm, GameState gs) {
        // TODO Auto-generated method stub
        //Can make this not need isComputerError....
        gs.setShowComputerError(isComputerError());
        gs.setComputerErrorCode(this.getErrorCode());

    }

    @Override
    public int getErrorCode() {
        // TODO Auto-generated method stub
        return 1201;
    }

    @Override
    public boolean isComputerError() {
        // TODO Auto-generated method stub
        return true;
    }

}
